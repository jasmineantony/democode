import machine
import network
from machine import Pin
import urequests
import time

# Connect to Wi-Fi
def connect_to_wifi():
    ssid = "YOUR_WIFI_SSID"
    password = "YOUR_WIFI_PASSWORD"
    station = network.WLAN(network.STA_IF)
    if not station.isconnected():
        print("Connecting to WiFi...")
        station.active(True)
        station.connect(ssid, password)
        while not station.isconnected():
            pass
    print("Connected to WiFi:", station.ifconfig())

# IR Sensor Setup
ir_sensor_pin = 14  # GPIO pin where the IR sensor is connected
ir_sensor = Pin(ir_sensor_pin, Pin.IN)

# Server URL to send IR sensor data
server_url = "http://example.com/ir_data"

# Main function
def main():
    connect_to_wifi()

    while True:
        ir_value = ir_sensor.value()  # Read IR sensor value (0 or 1)
        print("IR Sensor Value:", ir_value)

        # Send IR sensor data to the server
        try:
            response = urequests.post(server_url, json={"ir_value": ir_value})
            print("Server Response:", response.text)
            response.close()
        except Exception as e:
            print("Error:", e)

        time.sleep(1)  # Wait for 1 second before reading again

if __name__ == "__main__":
    main()
